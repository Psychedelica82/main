# Waldtriathlon in Trainingen

Dies ist die offizielle Microsite für den Waldtriathlon in Trainingen, der am Sonntag, den 15. September 2024, stattfindet. Die Seite bietet alle notwendigen Informationen zur Veranstaltung, einschließlich Ausschreibung, Anmeldung, Zeitplan und Rahmenprogramm.

## Inhaltsverzeichnis

- Projektübersicht
- Verzeichnisstruktur
- Verwendete Technologien
- Installation
- Verwendung
- Autoren
- Lizenz

## Projektübersicht

Die Microsite wurde entwickelt, um den Waldtriathlon in Trainingen zu bewerben und alle relevanten Informationen für Teilnehmer und Interessierte bereitzustellen. Die Seite ist responsiv gestaltet und passt sich verschiedenen Bildschirmgrößen an.

## Verzeichnisstruktur

## Verwendete Technologien- **HTML5**: Struktur der Webseite- **CSS3**: Styling der Webseite- **JavaScript**: Interaktive Elemente, wie das Hamburger-Menü und der Slider- **Font Awesome**: Icons für verschiedene Elemente auf der Seite## Installation1. **Repository klonen**:

https://github.com/dein-benutzername/waldtriathlon.git


2. **In das Projektverzeichnis wechseln**:

3. **Öffne die `index.html` Datei in deinem bevorzugten Browser**.## Verwendung- **Navigation**: Die Navigation enthält Links zu den verschiedenen Abschnitten der Seite. Auf mobilen Geräten wird ein Hamburger-Menü angezeigt.- **Slider**: Der Zeitplan-Slider zeigt die verschiedenen Zeitpunkte der Veranstaltung an. Navigationspfeile und Punkte ermöglichen das Durchblättern der Slides.- **Anmeldung**: Informationen zu den verschiedenen Wettkämpfen und die Möglichkeit zur Anmeldung.## Autoren- **Cornelia Geißinger** - *Initiale Arbeit* - dein-benutzername## LizenzDieses Projekt ist lizenziert unter der MIT-Lizenz - siehe die LICENSE Datei für Details.

Verwende am besten Mozilla Firefox um die Liveansicht zu betrachten.

